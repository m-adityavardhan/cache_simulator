from replacement_policy import ReplacementPolicy

# It inherits functions from parent class
class FIFO(ReplacementPolicy):
    pass
